package SHADOWFOX;

	import java.util.Scanner;

	public class EnhancedCalculator {

	    // Method for basic arithmetic operations
	    public static double add(double a, double b) {
	        return a + b;
	    }

	    public static double subtract(double a, double b) {
	        return a - b;
	    }

	    public static double multiply(double a, double b) {
	        return a * b;
	    }

	    public static double divide(double a, double b) throws ArithmeticException {
	        if (b == 0) {
	            throw new ArithmeticException("Error: Division by zero is not allowed.");
	        }
	        return a / b;
	    }

	    // Method for scientific calculations
	    public static double squareRoot(double a) {
	        if (a < 0) {
	            System.out.println("Error: Negative number for square root.");
	            return -1;
	        }
	        return Math.sqrt(a);
	    }

	    public static double exponentiation(double a, double b) {
	        return Math.pow(a, b);
	    }

	    // Method for unit conversions
	    public static double celsiusToFahrenheit(double celsius) {
	        return (celsius * 9 / 5) + 32;
	    }

	    public static double fahrenheitToCelsius(double fahrenheit) {
	        return (fahrenheit - 32) * 5 / 9;
	    }

	    public static double usdToEur(double usd) {
	        // Example conversion rate, it may fluctuate in real life.
	        return usd * 0.85;
	    }

	    public static double eurToUsd(double eur) {
	        // Example conversion rate, it may fluctuate in real life.
	        return eur * 1.18;
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        int choice;

	        do {
	            System.out.println("\nEnhanced Console Calculator");
	            System.out.println("1. Addition");
	            System.out.println("2. Subtraction");
	            System.out.println("3. Multiplication");
	            System.out.println("4. Division");
	            System.out.println("5. Square Root");
	            System.out.println("6. Exponentiation");
	            System.out.println("7. Celsius to Fahrenheit");
	            System.out.println("8. Fahrenheit to Celsius");
	            System.out.println("9. USD to EUR");
	            System.out.println("10. EUR to USD");
	            System.out.println("11. Exit");
	            System.out.print("Enter your choice: ");
	            choice = scanner.nextInt();

	            double num1, num2, result;
	            switch (choice) {
	                case 1: // Addition
	                    System.out.print("Enter first number: ");
	                    num1 = scanner.nextDouble();
	                    System.out.print("Enter second number: ");
	                    num2 = scanner.nextDouble();
	                    result = add(num1, num2);
	                    System.out.println("Result: " + result);
	                    break;
	                case 2: // Subtraction
	                    System.out.print("Enter first number: ");
	                    num1 = scanner.nextDouble();
	                    System.out.print("Enter second number: ");
	                    num2 = scanner.nextDouble();
	                    result = subtract(num1, num2);
	                    System.out.println("Result: " + result);
	                    break;
	                case 3: // Multiplication
	                    System.out.print("Enter first number: ");
	                    num1 = scanner.nextDouble();
	                    System.out.print("Enter second number: ");
	                    num2 = scanner.nextDouble();
	                    result = multiply(num1, num2);
	                    System.out.println("Result: " + result);
	                    break;
	                case 4: // Division
	                    System.out.print("Enter first number: ");
	                    num1 = scanner.nextDouble();
	                    System.out.print("Enter second number: ");
	                    num2 = scanner.nextDouble();
	                    try {
	                        result = divide(num1, num2);
	                        System.out.println("Result: " + result);
	                    } catch (ArithmeticException e) {
	                        System.out.println(e.getMessage());
	                    }
	                    break;
	                case 5: // Square Root
	                    System.out.print("Enter a number: ");
	                    num1 = scanner.nextDouble();
	                    result = squareRoot(num1);
	                    if (result != -1) {
	                        System.out.println("Result: " + result);
	                    }
	                    break;
	                case 6: // Exponentiation
	                    System.out.print("Enter base number: ");
	                    num1 = scanner.nextDouble();
	                    System.out.print("Enter exponent: ");
	                    num2 = scanner.nextDouble();
	                    result = exponentiation(num1, num2);
	                    System.out.println("Result: " + result);
	                    break;
	                case 7: // Celsius to Fahrenheit
	                    System.out.print("Enter temperature in Celsius: ");
	                    num1 = scanner.nextDouble();
	                    result = celsiusToFahrenheit(num1);
	                    System.out.println("Result: " + result + " °F");
	                    break;
	                case 8: // Fahrenheit to Celsius
	                    System.out.print("Enter temperature in Fahrenheit: ");
	                    num1 = scanner.nextDouble();
	                    result = fahrenheitToCelsius(num1);
	                    System.out.println("Result: " + result + " °C");
	                    break;
	                case 9: // USD to EUR
	                    System.out.print("Enter amount in USD: ");
	                    num1 = scanner.nextDouble();
	                    result = usdToEur(num1);
	                    System.out.println("Result: " + result + " EUR");
	                    break;
	                case 10: // EUR to USD
	                    System.out.print("Enter amount in EUR: ");
	                    num1 = scanner.nextDouble();
	                    result = eurToUsd(num1);
	                    System.out.println("Result: " + result + " USD");
	                    break;
	                case 11:
	                    System.out.println("Exiting...");
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        } while (choice != 11);

	        scanner.close();
	    }
	}


