package SHADOWFOX;
	import java.util.ArrayList;
	import java.util.Scanner;

	public class ContactManager {
	    private static ArrayList<Contact> contacts = new ArrayList<>();
	    private static Scanner scanner = new Scanner(System.in);

	    // Method to add a new contact
	    public static void addContact() {
	        System.out.println("Enter contact name:");
	        String name = scanner.nextLine();
	        System.out.println("Enter phone number:");
	        String phoneNumber = scanner.nextLine();
	        System.out.println("Enter email address:");
	        String email = scanner.nextLine();

	        contacts.add(new Contact(name, phoneNumber, email));
	        System.out.println("Contact added successfully!");
	    }

	    // Method to view all contacts
	    public static void viewContacts() {
	        if (contacts.isEmpty()) {
	            System.out.println("No contacts available.");
	            return;
	        }
	        for (int i = 0; i < contacts.size(); i++) {
	            System.out.println("Contact " + (i + 1) + ":");
	            contacts.get(i).displayContact();
	            System.out.println();
	        }
	    }

	    // Method to update an existing contact
	    public static void updateContact() {
	        System.out.println("Enter contact number to update:");
	        int index = scanner.nextInt() - 1;
	        scanner.nextLine();  // Consume the newline character

	        if (index < 0 || index >= contacts.size()) {
	            System.out.println("Invalid contact number.");
	            return;
	        }

	        System.out.println("Enter new name (Leave blank to keep unchanged):");
	        String name = scanner.nextLine();
	        if (!name.isEmpty()) contacts.get(index).name = name;

	        System.out.println("Enter new phone number (Leave blank to keep unchanged):");
	        String phoneNumber = scanner.nextLine();
	        if (!phoneNumber.isEmpty()) contacts.get(index).phoneNumber = phoneNumber;

	        System.out.println("Enter new email address (Leave blank to keep unchanged):");
	        String email = scanner.nextLine();
	        if (!email.isEmpty()) contacts.get(index).email = email;

	        System.out.println("Contact updated successfully!");
	    }

	    // Method to delete a contact
	    public static void deleteContact() {
	        System.out.println("Enter contact number to delete:");
	        int index = scanner.nextInt() - 1;
	        scanner.nextLine();  // Consume the newline character

	        if (index < 0 || index >= contacts.size()) {
	            System.out.println("Invalid contact number.");
	            return;
	        }

	        contacts.remove(index);
	        System.out.println("Contact deleted successfully!");
	    }

	    // Method to display menu options
	    public static void displayMenu() {
	        System.out.println("Contact Management System");
	        System.out.println("1. Add Contact");
	        System.out.println("2. View Contacts");
	        System.out.println("3. Update Contact");
	        System.out.println("4. Delete Contact");
	        System.out.println("5. Exit");
	        System.out.print("Enter your choice: ");
	    }

	    public static void main(String[] args) {
	        while (true) {
	            displayMenu();
	            int choice = scanner.nextInt();
	            scanner.nextLine();  // Consume the newline character

	            switch (choice) {
	                case 1:
	                    addContact();
	                    break;
	                case 2:
	                    viewContacts();
	                    break;
	                case 3:
	                    updateContact();
	                    break;
	                case 4:
	                    deleteContact();
	                    break;
	                case 5:
	                    System.out.println("Exiting...");
	                    System.exit(0);
	                default:
	                    System.out.println("Invalid choice! Please try again.");
	            }
	        }
	    }
	}
